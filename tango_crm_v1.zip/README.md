# Tango CRM — стартовый проект (Django)

Минимальный каркас под наше ТЗ: ученики, уроки (45 мин × N), блоки, платежи.
Запуск:
```
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
Админка: `/admin/`.
