from django.contrib import admin
from .models import Student, Lesson, Block, Payment

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display=('name','phone','email','price_single')
    search_fields=('name','phone','email')

@admin.register(Block)
class BlockAdmin(admin.ModelAdmin):
    list_display=('student','lessons_total','lessons_used','price','is_active','created_at')
    list_filter=('is_active',)
    search_fields=('student__name',)

@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    list_display=('student','date','start_time','count','pay_source','status')
    list_filter=('status','pay_source','date')
    search_fields=('student__name',)

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display=('student','date','amount','method')
    list_filter=('method',)
    search_fields=('student__name',)
